# Test module order

**Owner:** C. Đọc [quy tắc module](../../../../../../main/java/org/akira/laptopstore/order/README.md). Query foundation có unit test cho ownership, mapping snapshot và tổng số lượng; checkout workflow còn cần test liên module khi contract sẵn sàng.

## Hành vi cần chứng minh

rollback giữa checkout; hai người mua SKU cuối; request lặp; hủy lặp; chuyển trạng thái sai; khách đọc đơn người khác; callback thanh toán chạy đua với hủy.

Unit test cho service/quy tắc; web test cho DTO/status/role; repository test dùng PostgreSQL cho query/constraint/lock. Luồng nhiều module đặt ở integration và phối hợp owner contract. Không viết test để mirror getter hay công bố concurrency bằng test đơn luồng.

Tên class `*Test`/`*Tests` phù hợp runner hiện tại; `*IT` chỉ dùng khi cấu hình thêm Failsafe. Mỗi test dữ liệu độc lập, không phụ thuộc thứ tự hoặc DB cá nhân. Ghi lệnh/kết quả thật trong PR.
