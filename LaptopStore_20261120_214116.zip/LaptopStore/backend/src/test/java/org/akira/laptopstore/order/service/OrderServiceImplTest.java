package org.akira.laptopstore.order.service;

import org.akira.laptopstore.cart.dto.response.CartItemResponse;
import org.akira.laptopstore.cart.dto.response.CartResponse;
import org.akira.laptopstore.cart.dto.response.CartSnapshot;
import org.akira.laptopstore.cart.service.CartService;
import org.akira.laptopstore.catalog.dto.response.CheckoutVariantSnapshot;
import org.akira.laptopstore.catalog.service.CatalogCheckoutService;
import org.akira.laptopstore.exception.BusinessException;
import org.akira.laptopstore.exception.ResourceNotFoundException;
import org.akira.laptopstore.exception.ValidationException;
import org.springframework.http.HttpStatus;
import org.akira.laptopstore.inventory.service.InventoryService;
import org.akira.laptopstore.order.dto.request.CheckoutPreviewRequest;
import org.akira.laptopstore.order.dto.request.CreateOrderRequest;
import org.akira.laptopstore.order.dto.request.UpdateOrderStatusRequest;
import org.akira.laptopstore.order.entity.Order;
import org.akira.laptopstore.order.entity.OrderItem;
import org.akira.laptopstore.order.entity.OrderStatusHistory;
import org.akira.laptopstore.order.entity.enums.OrderStatus;
import org.akira.laptopstore.order.event.OrderCancelledEvent;
import org.akira.laptopstore.order.event.OrderCreatedEvent;
import org.akira.laptopstore.order.mapper.OrderMapper;
import org.akira.laptopstore.order.repository.OrderItemRepository;
import org.akira.laptopstore.order.repository.OrderRepository;
import org.akira.laptopstore.order.repository.OrderStatusHistoryRepository;
import org.akira.laptopstore.order.service.impl.OrderCheckoutSupport;
import org.akira.laptopstore.order.service.impl.OrderExpirationTxHelper;
import org.akira.laptopstore.order.service.impl.OrderServiceImpl;
import org.akira.laptopstore.promotion.dto.response.CouponEvaluation;
import org.akira.laptopstore.promotion.service.CouponService;
import org.akira.laptopstore.promotion.service.LoyaltyService;
import org.akira.laptopstore.user.dto.AddressResponse;
import org.akira.laptopstore.user.service.AddressService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock private OrderRepository orders;
    @Mock private OrderItemRepository orderItems;
    @Mock private OrderStatusHistoryRepository histories;
    @Mock private CartService cartService;
    @Mock private CatalogCheckoutService catalogCheckoutService;
    @Mock private InventoryService inventoryService;
    @Mock private AddressService addressService;
    @Mock private CouponService couponService;
    @Mock private LoyaltyService loyaltyService;
    @Mock private ApplicationEventPublisher eventPublisher;

    private OrderExpirationTxHelper expirationTxHelper;
    private OrderServiceImpl service;

    @BeforeEach
    void setUp() {
        OrderCheckoutSupport checkoutSupport = new OrderCheckoutSupport(addressService, couponService);
        expirationTxHelper = new OrderExpirationTxHelper(
                orders,
                orderItems,
                histories,
                inventoryService,
                couponService,
                eventPublisher
        );
        service = new OrderServiceImpl(
                orders,
                orderItems,
                histories,
                new OrderMapper(),
                cartService,
                catalogCheckoutService,
                inventoryService,
                couponService,
                loyaltyService,
                checkoutSupport,
                expirationTxHelper,
                eventPublisher
        );
    }

    @Test
    void ownerCanReadDetailWithStoredItemAndStatusSnapshots() {
        Order order = order(10L, 42L);
        when(orders.findById(10L)).thenReturn(Optional.of(order));
        when(orderItems.findByOrderId(10L)).thenReturn(List.of(OrderItem.builder()
                .id(20L).productId(2L).variantId(3L).productName("Laptop")
                .variantName("16GB / 512GB").sku("LP-3").unitPrice(new BigDecimal("12500000"))
                .quantity(2).build()));
        when(histories.findByOrderIdOrderByChangedAtDesc(10L)).thenReturn(List.of(OrderStatusHistory.builder()
                .id(30L).toStatus(OrderStatus.CONFIRMED).changedAt(Instant.parse("2026-10-01T10:00:00Z"))
                .changedByUserId(42L).build()));

        var response = service.getOwnOrder(42L, 10L);

        assertEquals("ORD-10", response.getOrderCode());
        assertEquals(new BigDecimal("25000000"), response.getItems().getFirst().getLineTotal());
        assertEquals(OrderStatus.CONFIRMED, response.getStatusHistories().getFirst().getToStatus());
    }

    @Test
    void userCannotReadAnotherUsersOrder() {
        when(orders.findById(10L)).thenReturn(Optional.of(order(10L, 99L)));

        assertThrows(ResourceNotFoundException.class, () -> service.getOwnOrder(42L, 10L));
    }

    @Test
    void orderListsContainTheQuantityAcrossAllLines() {
        Order order = order(10L, 42L);
        when(orders.findByUserId(42L, PageRequest.of(0, 20))).thenReturn(new PageImpl<>(List.of(order)));
        when(orderItems.sumQuantitiesByOrderIds(List.of(10L)))
                .thenReturn(List.<Object[]>of(new Object[]{10L, 3L}));

        var result = service.getOwnOrders(42L, PageRequest.of(0, 20));

        assertEquals(3, result.getContent().getFirst().getTotalItems());
    }

    @Test
    void createOrderWithAddressIdAndCouponCalculatesTotalsAndValidatesStock() {
        when(addressService.getAddressById(42L, 15L)).thenReturn(AddressResponse.builder()
                .id(15L)
                .userId(42L)
                .recipientName("Phan Anh Khang")
                .phone("0901234567")
                .street("123 Nguyen Trai")
                .ward("Phuong 2")
                .district("Quan 5")
                .city("TP. Ho Chi Minh")
                .postalCode("700000")
                .isDefault(true)
                .build());

        when(cartService.lockAndGetCheckoutCart(42L)).thenReturn(new CartSnapshot(3L, 42L,
                List.of(new CartSnapshot.Item(9L, 7L, 2))));
        when(catalogCheckoutService.lockAndGetSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "MacBook Air M3", "16GB - 512GB - Silver",
                        "MBA-M3-16-512", new BigDecimal("15000000.00"), 5)));

        CouponEvaluation evaluation = new CouponEvaluation(1L, "STUDENT10", new BigDecimal("1500000.00"));
        when(couponService.evaluateForCheckout("STUDENT10", 42L, new BigDecimal("30000000.00")))
                .thenReturn(evaluation);
        when(couponService.reserveForOrder("STUDENT10", 42L, 100L, new BigDecimal("30000000.00")))
                .thenReturn(evaluation);

        when(orders.saveAndFlush(any(Order.class))).thenAnswer(invocation -> {
            Order saved = invocation.getArgument(0);
            saved.setId(100L);
            saved.setCreatedAt(Instant.parse("2026-10-14T10:00:00Z"));
            saved.setUpdatedAt(saved.getCreatedAt());
            return saved;
        });
        when(orderItems.saveAll(any())).thenAnswer(invocation -> {
            Iterable<OrderItem> input = invocation.getArgument(0);
            List<OrderItem> list = new ArrayList<>();
            input.forEach(list::add);
            return list;
        });
        when(histories.save(any(OrderStatusHistory.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .addressId(15L)
                .paymentMethod("VNPAY")
                .couponCode("student10")
                .note("  Giao giờ hành chính  ")
                .idempotencyKey("idem-week4-001")
                .build();

        var response = service.createOrder(42L, request);

        assertEquals(100L, response.getId());
        assertEquals("Giao giờ hành chính", response.getNote());
        assertEquals("Phan Anh Khang", response.getRecipientName());
        assertEquals("0901234567", response.getRecipientPhone());
        assertEquals("123 Nguyen Trai, Phuong 2, Quan 5, TP. Ho Chi Minh, 700000", response.getShippingAddress());
        assertEquals(new BigDecimal("30000000.00"), response.getSubtotal());
        assertEquals(new BigDecimal("1500000.00"), response.getDiscountAmount());
        assertEquals(BigDecimal.ZERO, response.getShippingFee());
        assertEquals(new BigDecimal("28500000.00"), response.getTotalAmount());
        assertEquals("STUDENT10", response.getCouponCodeSnapshot());

        verify(couponService).evaluateForCheckout("STUDENT10", 42L, new BigDecimal("30000000.00"));
        verify(couponService).reserveForOrder("STUDENT10", 42L, 100L, new BigDecimal("30000000.00"));
        verify(inventoryService).deductForOrder(eq(100L), eq(42L), any());
        verify(eventPublisher).publishEvent(any(OrderCreatedEvent.class));
        verify(cartService).clearPurchasedItems(42L, List.of(9L));
    }

    @Test
    void createOrderRejectsInsufficientStockBeforeSavingOrder() {
        when(cartService.lockAndGetCheckoutCart(42L)).thenReturn(new CartSnapshot(3L, 42L,
                List.of(new CartSnapshot.Item(9L, 7L, 4))));
        when(catalogCheckoutService.lockAndGetSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "MacBook Air M3", "16GB - 512GB - Silver",
                        "MBA-M3-16-512", new BigDecimal("15000000.00"), 2)));

        CreateOrderRequest request = new CreateOrderRequest(
                "Nguyen Van A", "0900000000", "Ho Chi Minh City", null, null, null);

        assertThrows(ValidationException.class, () -> service.createOrder(42L, request));

        verify(orders, never()).saveAndFlush(any());
        verifyNoInteractions(orderItems, histories, inventoryService, couponService);
    }

    @Test
    void createOrderRejectsInvalidCouponBeforeSavingOrder() {
        when(cartService.lockAndGetCheckoutCart(42L)).thenReturn(new CartSnapshot(3L, 42L,
                List.of(new CartSnapshot.Item(9L, 7L, 1))));
        when(catalogCheckoutService.lockAndGetSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "MacBook Air M3", "16GB - 512GB - Silver",
                        "MBA-M3-16-512", new BigDecimal("15000000.00"), 5)));
        when(couponService.evaluateForCheckout("EXPIRED", 42L, new BigDecimal("15000000.00")))
                .thenThrow(new ValidationException("Coupon has expired"));

        CreateOrderRequest request = new CreateOrderRequest(
                "Nguyen Van A", "0900000000", "Ho Chi Minh City", "EXPIRED", null, null);

        assertThrows(ValidationException.class, () -> service.createOrder(42L, request));

        verify(orders, never()).saveAndFlush(any());
        verify(couponService, never()).reserveForOrder(any(), any(), any(), any());
        verifyNoInteractions(orderItems, histories, inventoryService);
    }

    @Test
    void createOrderRejectsUnsupportedPaymentMethodBeforeTouchingCart() {
        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("BITCOIN")
                .build();

        assertThrows(ValidationException.class, () -> service.createOrder(42L, request));

        verifyNoInteractions(cartService, catalogCheckoutService, orders, inventoryService, couponService);
    }

    @Test
    void previewCheckoutCalculatesBreakdownWithoutMutatingOrderOrCart() {
        when(cartService.getCart(42L)).thenReturn(new CartResponse(
                3L,
                List.of(new CartItemResponse(9L, 7L, "Laptop A", "SKU-7", "16GB / 512GB",
                        2, new BigDecimal("10000000.00"), new BigDecimal("20000000.00"))),
                2,
                new BigDecimal("20000000.00")
        ));
        when(catalogCheckoutService.getSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "Laptop A", "16GB / 512GB", "SKU-7",
                        new BigDecimal("10000000.00"), 10)));
        when(couponService.evaluateForCheckout("SALE500K", 42L, new BigDecimal("20000000.00")))
                .thenReturn(new CouponEvaluation(2L, "SALE500K", new BigDecimal("500000.00")));

        var preview = service.previewCheckout(42L, CheckoutPreviewRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("123 Le Loi, Q1, TP.HCM")
                .paymentMethod("COD")
                .couponCode("sale500k")
                .build());

        assertEquals("COD", preview.getPaymentMethod());
        assertEquals("SALE500K", preview.getCouponCode());
        assertEquals(new BigDecimal("20000000.00"), preview.getSubtotal());
        assertEquals(new BigDecimal("500000.00"), preview.getDiscountAmount());
        assertEquals(BigDecimal.ZERO, preview.getShippingFee());
        assertEquals(new BigDecimal("19500000.00"), preview.getTotalAmount());
        assertEquals(2, preview.getTotalItems());

        verifyNoInteractions(orders, orderItems, histories, inventoryService);
    }

    @Test
    void staffCanUpdateStatusToPackedWhenOrderIsConfirmed() {
        Order order = order(10L, 42L);
        order.setStatus(OrderStatus.CONFIRMED);
        when(orders.findByIdForUpdate(10L)).thenReturn(Optional.of(order));
        when(histories.findByOrderIdOrderByChangedAtDesc(10L)).thenReturn(List.of());

        var response = service.updateOrderStatus(99L, 10L, new UpdateOrderStatusRequest(OrderStatus.PACKING, "Packed by staff"));

        assertEquals(OrderStatus.PACKING, order.getStatus());
        verify(orders).save(order);
        ArgumentCaptor<OrderStatusHistory> historyCaptor = ArgumentCaptor.forClass(OrderStatusHistory.class);
        verify(histories).save(historyCaptor.capture());
        assertEquals("Packed by staff", historyCaptor.getValue().getNote());
    }

    @Test
    void userCanCancelUnpaidOnlineOrderAndRestoresStockAndCoupon() {
        Order order = order(10L, 42L);
        order.setStatus(OrderStatus.PENDING_PAYMENT);
        order.setCouponCodeSnapshot("DISCOUNT10");
        when(orders.findByIdForUpdate(10L)).thenReturn(Optional.of(order));
        when(orderItems.findByOrderId(10L)).thenReturn(List.of(OrderItem.builder()
                .id(20L).productId(1L).variantId(5L).quantity(2).unitPrice(BigDecimal.TEN).build()));
        when(histories.findByOrderIdOrderByChangedAtDesc(10L)).thenReturn(List.of());

        var response = service.cancelOrder(42L, 10L, "Changed my mind");

        assertEquals(OrderStatus.CANCELLED, order.getStatus());
        ArgumentCaptor<OrderStatusHistory> historyCaptor = ArgumentCaptor.forClass(OrderStatusHistory.class);
        verify(histories).save(historyCaptor.capture());
        assertEquals("Changed my mind", historyCaptor.getValue().getNote());
        verify(inventoryService).restoreForOrder(eq(10L), eq(42L), any());
        verify(couponService).releaseForOrder(10L);
        verify(eventPublisher).publishEvent(new OrderCancelledEvent(10L, false));
    }

    @Test
    void expirePendingOrdersCancelsExpiredOrdersAndRestoresStockAndCoupons() {
        Order expiredOrder = order(101L, 42L);
        expiredOrder.setStatus(OrderStatus.PENDING_PAYMENT);
        expiredOrder.setCouponCodeSnapshot("EXPIRED10");
        expiredOrder.setCreatedAt(Instant.now().minus(30, ChronoUnit.MINUTES));

        when(orders.findIdsByStatusAndCreatedAtBefore(eq(OrderStatus.PENDING_PAYMENT), any(Instant.class), any()))
                .thenReturn(List.of(101L));
        when(orders.findByIdForUpdateSkipLocked(101L)).thenReturn(Optional.of(expiredOrder));
        when(orderItems.findByOrderId(101L)).thenReturn(List.of(OrderItem.builder()
                .id(1L).productId(10L).variantId(20L).quantity(1).unitPrice(BigDecimal.TEN).build()));

        int cancelledCount = service.expirePendingOrders(Duration.ofMinutes(15));

        assertEquals(1, cancelledCount);
        assertEquals(OrderStatus.CANCELLED, expiredOrder.getStatus());
        verify(orders).save(expiredOrder);
        ArgumentCaptor<OrderStatusHistory> historyCaptor = ArgumentCaptor.forClass(OrderStatusHistory.class);
        verify(histories).save(historyCaptor.capture());
        assertEquals("Tự động hủy do quá thời hạn thanh toán online", historyCaptor.getValue().getNote());
        verify(inventoryService).restoreForOrder(eq(101L), isNull(), any());
        verify(couponService).releaseForOrder(101L);
        verify(eventPublisher).publishEvent(new OrderCancelledEvent(101L, true));
    }

    @Test
    void expirePendingOrdersDoesNothingWhenNoExpiredOrders() {
        when(orders.findIdsByStatusAndCreatedAtBefore(eq(OrderStatus.PENDING_PAYMENT), any(Instant.class), any()))
                .thenReturn(List.of());

        int cancelledCount = service.expirePendingOrders(Duration.ofMinutes(15));

        assertEquals(0, cancelledCount);
        verify(orders, never()).save(any());
        verifyNoInteractions(inventoryService);
    }

    @Test
    void duplicateCancellationDoesNotRestoreTwice() {
        Order order = order(10L, 42L);
        order.setStatus(OrderStatus.CANCELLED);
        when(orders.findByIdForUpdate(10L)).thenReturn(Optional.of(order));
        assertEquals(OrderStatus.CANCELLED, service.cancelOrder(42L, 10L, null).getStatus());
        verifyNoInteractions(inventoryService, couponService);
        verify(histories, never()).save(any());
    }

    @Test
    void expirationPropagatesRestoreFailureForSingleOrderTransactionRollback() {
        Order order = order(10L, 42L);
        order.setStatus(OrderStatus.PENDING_PAYMENT);
        order.setCreatedAt(Instant.now().minus(30, ChronoUnit.MINUTES));
        when(orders.findByIdForUpdateSkipLocked(10L)).thenReturn(Optional.of(order));
        when(orderItems.findByOrderId(10L)).thenReturn(List.of(OrderItem.builder()
                .variantId(7L).quantity(1).build()));
        doThrow(new IllegalStateException("stock unavailable")).when(inventoryService)
                .restoreForOrder(eq(10L), isNull(), any());
        assertThrows(IllegalStateException.class,
                () -> expirationTxHelper.expireSinglePendingOrder(10L, Instant.now().minus(15, ChronoUnit.MINUTES)));
    }

    @Test
    void staffCannotConfirmAnUnpaidOnlineOrder() {
        Order order = order(10L, 42L);
        order.setStatus(OrderStatus.PENDING_PAYMENT);
        when(orders.findByIdForUpdate(10L)).thenReturn(Optional.of(order));
        assertThrows(ValidationException.class, () -> service.updateOrderStatus(99L, 10L,
                new UpdateOrderStatusRequest(OrderStatus.CONFIRMED, null)));
        verify(orders, never()).save(any());
    }

    @Test
    void getOwnOrdersDoesNotTriggerNPlusOnePerOrder() {
        Order first = order(10L, 42L);
        Order second = order(11L, 42L);
        when(orders.findByUserId(42L, PageRequest.of(0, 20)))
                .thenReturn(new PageImpl<>(List.of(first, second)));
        when(orderItems.sumQuantitiesByOrderIds(List.of(10L, 11L)))
                .thenReturn(List.<Object[]>of(new Object[]{10L, 3L}, new Object[]{11L, 2L}));

        var page = service.getOwnOrders(42L, PageRequest.of(0, 20));

        assertEquals(3, page.getContent().get(0).getTotalItems());
        assertEquals(2, page.getContent().get(1).getTotalItems());
        verify(orderItems, times(1)).sumQuantitiesByOrderIds(List.of(10L, 11L));
        verify(orderItems, never()).findByOrderId(any());
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndSamePayloadReturnsExistingOrder() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-same-001");
        when(orders.findByIdempotencyKeyAndUserId("idem-same-001", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));
        when(orderItems.findByOrderId(100L)).thenReturn(List.of());
        when(cartService.getCart(42L)).thenReturn(new CartResponse(3L, List.of(), 0, BigDecimal.ZERO));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-same-001")
                .build();

        var response = service.createOrder(42L, request);

        assertEquals(100L, response.getId());
        verify(cartService, never()).lockAndGetCheckoutCart(any());
        verify(cartService, never()).clearPurchasedItems(any(), any());
        verifyNoInteractions(catalogCheckoutService, inventoryService);
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndDifferentCartProductThrowsConflict() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-diff-item");
        when(orders.findByIdempotencyKeyAndUserId("idem-diff-item", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));
        when(orderItems.findByOrderId(100L)).thenReturn(List.of(
                OrderItem.builder().id(1L).variantId(7L).quantity(1).unitPrice(new BigDecimal("25000000")).build()
        ));
        when(cartService.getCart(42L)).thenReturn(new CartResponse(
                3L,
                List.of(new CartItemResponse(9L, 8L, "Laptop B", "SKU-8", "32GB", 1,
                        new BigDecimal("25000000"), new BigDecimal("25000000"))),
                1,
                new BigDecimal("25000000")
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-diff-item")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createOrder(42L, request));
        assertEquals(HttpStatus.CONFLICT, ex.getStatus());
        assertEquals("IDEMPOTENCY_CONFLICT", ex.getCode());
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndDifferentQuantityThrowsConflict() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-diff-qty");
        when(orders.findByIdempotencyKeyAndUserId("idem-diff-qty", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));
        when(orderItems.findByOrderId(100L)).thenReturn(List.of(
                OrderItem.builder().id(1L).variantId(7L).quantity(1).unitPrice(new BigDecimal("25000000")).build()
        ));
        when(cartService.getCart(42L)).thenReturn(new CartResponse(
                3L,
                List.of(new CartItemResponse(9L, 7L, "Laptop A", "SKU-7", "16GB", 2,
                        new BigDecimal("25000000"), new BigDecimal("50000000"))),
                2,
                new BigDecimal("50000000")
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-diff-qty")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createOrder(42L, request));
        assertEquals(HttpStatus.CONFLICT, ex.getStatus());
        assertEquals("IDEMPOTENCY_CONFLICT", ex.getCode());
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndDifferentPriceThrowsConflict() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-diff-price");
        when(orders.findByIdempotencyKeyAndUserId("idem-diff-price", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));
        when(orderItems.findByOrderId(100L)).thenReturn(List.of(
                OrderItem.builder().id(1L).variantId(7L).quantity(1).unitPrice(new BigDecimal("25000000")).build()
        ));
        when(cartService.getCart(42L)).thenReturn(new CartResponse(
                3L,
                List.of(new CartItemResponse(9L, 7L, "Laptop A", "SKU-7", "16GB", 1,
                        new BigDecimal("27000000"), new BigDecimal("27000000"))),
                1,
                new BigDecimal("27000000")
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-diff-price")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createOrder(42L, request));
        assertEquals(HttpStatus.CONFLICT, ex.getStatus());
        assertEquals("IDEMPOTENCY_CONFLICT", ex.getCode());
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndIdenticalNonEmptyCartReturnsExistingOrder() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-same-cart");
        when(orders.findByIdempotencyKeyAndUserId("idem-same-cart", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));
        when(orderItems.findByOrderId(100L)).thenReturn(List.of(
                OrderItem.builder().id(1L).variantId(7L).quantity(1).unitPrice(new BigDecimal("25000000")).build()
        ));
        when(cartService.getCart(42L)).thenReturn(new CartResponse(
                3L,
                List.of(new CartItemResponse(9L, 7L, "Laptop A", "SKU-7", "16GB", 1,
                        new BigDecimal("25000000"), new BigDecimal("25000000"))),
                1,
                new BigDecimal("25000000")
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-same-cart")
                .build();

        var response = service.createOrder(42L, request);

        assertEquals(100L, response.getId());
        verify(cartService, never()).lockAndGetCheckoutCart(any());
        verifyNoInteractions(catalogCheckoutService, inventoryService);
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndDifferentPaymentMethodThrowsConflict() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-conflict-pm");
        when(orders.findByIdempotencyKeyAndUserId("idem-conflict-pm", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("VNPAY")
                .idempotencyKey("idem-conflict-pm")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createOrder(42L, request));
        assertEquals(HttpStatus.CONFLICT, ex.getStatus());
        assertEquals("IDEMPOTENCY_CONFLICT", ex.getCode());
    }

    @Test
    void createOrderWithSameIdempotencyKeyAndDifferentPayloadThrowsConflict() {
        Order previous = order(100L, 42L);
        previous.setStatus(OrderStatus.WAITING_CONFIRMATION);
        previous.setIdempotencyKey("idem-conflict-addr");
        when(orders.findByIdempotencyKeyAndUserId("idem-conflict-addr", 42L))
                .thenReturn(Optional.of(previous));
        when(histories.findByOrderIdOrderByChangedAtDesc(100L)).thenReturn(List.of(
                OrderStatusHistory.builder().id(1L).fromStatus(null).toStatus(OrderStatus.WAITING_CONFIRMATION).build()
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van B")
                .recipientPhone("0900000000")
                .shippingAddress("Ha Noi")
                .paymentMethod("COD")
                .idempotencyKey("idem-conflict-addr")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createOrder(42L, request));
        assertEquals(HttpStatus.CONFLICT, ex.getStatus());
        assertEquals("IDEMPOTENCY_CONFLICT", ex.getCode());
    }

    @Test
    void getStaffOrderReadsOrderOnlyOnce() {
        Order order = order(10L, 42L);
        when(orders.findById(10L)).thenReturn(Optional.of(order));
        when(orderItems.findByOrderId(10L)).thenReturn(List.of());
        when(histories.findByOrderIdOrderByChangedAtDesc(10L)).thenReturn(List.of());

        var response = service.getStaffOrder(10L);

        assertEquals(10L, response.getId());
        verify(orders, times(1)).findById(10L);
    }

    @Test
    void getDashboardSummaryAggregatesCountsAndRevenueAcrossAllOrders() {
        when(orders.summarizeByStatus()).thenReturn(List.of(
                new Object[]{OrderStatus.WAITING_CONFIRMATION, 3L, new BigDecimal("30000000")},
                new Object[]{OrderStatus.PENDING_PAYMENT, 2L, new BigDecimal("20000000")},
                new Object[]{OrderStatus.CONFIRMED, 4L, new BigDecimal("40000000")},
                new Object[]{OrderStatus.PACKING, 1L, new BigDecimal("10000000")},
                new Object[]{OrderStatus.SHIPPING, 2L, new BigDecimal("25000000")},
                new Object[]{OrderStatus.DELIVERED, 5L, new BigDecimal("125000000")},
                new Object[]{OrderStatus.CANCELLED, 1L, new BigDecimal("15000000")}
        ));

        var summary = service.getDashboardSummary();

        assertEquals(18L, summary.getTotalOrders());
        assertEquals(5L, summary.getPendingCount());
        assertEquals(7L, summary.getInProgressCount());
        assertEquals(5L, summary.getDeliveredCount());
        assertEquals(new BigDecimal("125000000"), summary.getDeliveredRevenue());
    }

    @Test
    void createOrderThrowsIdempotencyConflictWhenSaveFailsWithUserIdempotencyConstraint() {
        when(orders.findByIdempotencyKeyAndUserId("idem-race-001", 42L)).thenReturn(Optional.empty());
        when(cartService.lockAndGetCheckoutCart(42L)).thenReturn(new CartSnapshot(
                3L,
                42L,
                List.of(new CartSnapshot.Item(9L, 7L, 1))
        ));
        when(catalogCheckoutService.lockAndGetSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "MacBook Air M3", "16GB - 512GB - Silver",
                        "MBA-M3-16-512", new BigDecimal("25000000"), 5)
        ));
        when(orders.saveAndFlush(any(Order.class))).thenThrow(new DataIntegrityViolationException(
                "could not execute statement [ERROR: duplicate key value violates unique constraint \"uq_orders_user_idempotency_key\"]"
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-race-001")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createOrder(42L, request));
        assertEquals(HttpStatus.CONFLICT, ex.getStatus());
        assertEquals("IDEMPOTENCY_CONFLICT", ex.getCode());
    }

    @Test
    void createOrderRethrowsNonIdempotencyDataIntegrityViolation() {
        when(orders.findByIdempotencyKeyAndUserId("idem-other-err", 42L)).thenReturn(Optional.empty());
        when(cartService.lockAndGetCheckoutCart(42L)).thenReturn(new CartSnapshot(
                3L,
                42L,
                List.of(new CartSnapshot.Item(9L, 7L, 1))
        ));
        when(catalogCheckoutService.lockAndGetSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "MacBook Air M3", "16GB - 512GB - Silver",
                        "MBA-M3-16-512", new BigDecimal("25000000"), 5)
        ));
        when(orders.saveAndFlush(any(Order.class))).thenThrow(new DataIntegrityViolationException(
                "duplicate key value violates unique constraint \"uq_orders_order_code\""
        ));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City")
                .paymentMethod("COD")
                .idempotencyKey("idem-other-err")
                .build();

        assertThrows(DataIntegrityViolationException.class, () -> service.createOrder(42L, request));
    }

    @Test
    void returnedOrderDoesNotReleaseCouponOrUseCancelRestore() {
        Order delivered = order(55L, 42L);
        delivered.setStatus(OrderStatus.DELIVERED);
        delivered.setCouponCodeSnapshot("VIP500");
        when(orders.findByIdForUpdate(55L)).thenReturn(Optional.of(delivered));
        when(histories.findByOrderIdOrderByChangedAtDesc(55L)).thenReturn(List.of());
        when(orderItems.findByOrderId(55L)).thenReturn(List.of(OrderItem.builder()
                .id(1L).productId(10L).variantId(7L).quantity(1).unitPrice(new BigDecimal("25000000")).build()));

        service.updateOrderStatus(99L, 55L, new UpdateOrderStatusRequest(OrderStatus.RETURNED, "Máy lỗi màn hình"));

        assertEquals(OrderStatus.RETURNED, delivered.getStatus());
        verify(inventoryService).restoreForReturnedOrder(eq(55L), eq(99L), any());
        verify(inventoryService, never()).restoreForOrder(any(), any(), any());
        verify(couponService, never()).releaseForOrder(any());
        verify(eventPublisher, never()).publishEvent(any(OrderCancelledEvent.class));
    }

    @Test
    void expirePendingOrdersIsolatesFailureSoHealthyOrdersStillExpire() {
        Order brokenOrder = order(201L, 42L);
        brokenOrder.setStatus(OrderStatus.PENDING_PAYMENT);
        brokenOrder.setCreatedAt(Instant.now().minus(30, ChronoUnit.MINUTES));

        Order healthyOrder = order(202L, 43L);
        healthyOrder.setStatus(OrderStatus.PENDING_PAYMENT);
        healthyOrder.setCreatedAt(Instant.now().minus(30, ChronoUnit.MINUTES));

        when(orders.findIdsByStatusAndCreatedAtBefore(eq(OrderStatus.PENDING_PAYMENT), any(), any()))
                .thenReturn(List.of(201L, 202L));
        when(orders.findByIdForUpdateSkipLocked(201L)).thenReturn(Optional.of(brokenOrder));
        when(orders.findByIdForUpdateSkipLocked(202L)).thenReturn(Optional.of(healthyOrder));
        when(orderItems.findByOrderId(201L)).thenReturn(List.of(OrderItem.builder()
                .id(1L).variantId(7L).quantity(1).unitPrice(BigDecimal.TEN).build()));
        when(orderItems.findByOrderId(202L)).thenReturn(List.of(OrderItem.builder()
                .id(2L).variantId(8L).quantity(1).unitPrice(BigDecimal.TEN).build()));
        doThrow(new IllegalStateException("poison order")).when(inventoryService)
                .restoreForOrder(eq(201L), isNull(), any());

        int cancelledCount = service.expirePendingOrders(Duration.ofMinutes(15));

        assertEquals(1, cancelledCount);
        assertEquals(OrderStatus.CANCELLED, healthyOrder.getStatus());
        verify(inventoryService).restoreForOrder(eq(202L), isNull(), any());
        verify(eventPublisher).publishEvent(new OrderCancelledEvent(202L, true));
    }

    @Test
    void orderServiceSupportsServerSideStatusAndKeywordFiltering() {
        Order match = order(88L, 42L);
        match.setStatus(OrderStatus.DELIVERED);
        when(orders.searchAllOrders(eq(OrderStatus.DELIVERED), eq("%ord-88%"), any()))
                .thenReturn(new PageImpl<>(List.of(match)));
        when(orderItems.sumQuantitiesByOrderIds(List.of(88L)))
                .thenReturn(List.<Object[]>of(new Object[]{88L, 2L}));

        var staffPage = service.getAllOrders(OrderStatus.DELIVERED, "  ORD-88 ", PageRequest.of(0, 20));
        assertEquals(1, staffPage.getTotalElements());
        assertEquals("ORD-88", staffPage.getContent().getFirst().getOrderCode());
        verify(orders).searchAllOrders(eq(OrderStatus.DELIVERED), eq("%ord-88%"), any());

        List<OrderStatus> pendingGroup = List.of(OrderStatus.PENDING_PAYMENT, OrderStatus.WAITING_CONFIRMATION);
        when(orders.findByUserIdAndStatusIn(eq(42L), eq(pendingGroup), any()))
                .thenReturn(new PageImpl<>(List.of(match)));
        var ownPage = service.getOwnOrders(42L, pendingGroup, PageRequest.of(0, 20));
        assertEquals(1, ownPage.getTotalElements());
        verify(orders).findByUserIdAndStatusIn(eq(42L), eq(pendingGroup), any());
    }

    @Test
    void createOrderRejectsMalformedRecipientPhone() {
        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("abc-not-phone")
                .shippingAddress("123 Nguyen Trai, TP.HCM")
                .paymentMethod("COD")
                .build();

        assertThrows(ValidationException.class, () -> service.createOrder(42L, request));
        verifyNoInteractions(cartService, catalogCheckoutService);
    }

    @Test
    void getDashboardSummaryIncludesDeliveryFailedInInProgressCount() {
        when(orders.summarizeByStatus()).thenReturn(List.of(
                new Object[]{OrderStatus.CONFIRMED, 1L, new BigDecimal("10000000")},
                new Object[]{OrderStatus.SHIPPING, 2L, new BigDecimal("20000000")},
                new Object[]{OrderStatus.DELIVERY_FAILED, 3L, new BigDecimal("30000000")}
        ));

        var summary = service.getDashboardSummary();

        assertEquals(6L, summary.getTotalOrders());
        assertEquals(6L, summary.getInProgressCount());
    }

    @Test
    void cartAndOrderContractsSupportPartialCartItemSelection() {
        when(cartService.lockAndGetCheckoutCart(42L, List.of(9L))).thenReturn(new CartSnapshot(
                3L, 42L, List.of(new CartSnapshot.Item(9L, 7L, 1))
        ));
        when(catalogCheckoutService.lockAndGetSellableVariants(List.of(7L))).thenReturn(List.of(
                new CheckoutVariantSnapshot(7L, 70L, "MacBook Air M3", "16GB - 512GB",
                        "MBA-M3", new BigDecimal("20000000"), 5)
        ));
        when(orders.saveAndFlush(any(Order.class))).thenAnswer(inv -> {
            Order saved = inv.getArgument(0);
            saved.setId(300L);
            saved.setCreatedAt(Instant.now());
            saved.setUpdatedAt(saved.getCreatedAt());
            return saved;
        });
        when(orderItems.saveAll(any())).thenAnswer(inv -> inv.getArgument(0));
        when(histories.save(any(OrderStatusHistory.class))).thenAnswer(inv -> inv.getArgument(0));

        CreateOrderRequest request = CreateOrderRequest.builder()
                .recipientName("Nguyen Van A")
                .recipientPhone("0901234567")
                .shippingAddress("123 Nguyen Trai, TP.HCM")
                .paymentMethod("COD")
                .cartItemIds(List.of(9L))
                .build();

        var response = service.createOrder(42L, request);

        assertEquals(300L, response.getId());
        verify(cartService).lockAndGetCheckoutCart(42L, List.of(9L));
        verify(cartService).clearPurchasedItems(42L, List.of(9L));
    }

    @Test
    void updateOrderStatusToDeliveredAwardsLoyaltyPoints() {
        Order shippingOrder = order(700L, 42L);
        shippingOrder.setStatus(OrderStatus.SHIPPING);
        shippingOrder.setTotalAmount(new BigDecimal("25000000"));
        when(orders.findByIdForUpdate(700L)).thenReturn(Optional.of(shippingOrder));
        when(histories.findByOrderIdOrderByChangedAtDesc(700L)).thenReturn(List.of());
        when(orderItems.findByOrderId(700L)).thenReturn(List.of());

        UpdateOrderStatusRequest request = new UpdateOrderStatusRequest();
        request.setStatus(OrderStatus.DELIVERED);
        request.setNote("Giao thành công");

        var response = service.updateOrderStatus(99L, 700L, request);

        assertEquals(OrderStatus.DELIVERED, response.getStatus());
        verify(loyaltyService).awardPointsForDeliveredOrder(
                42L, 700L, "ORD-700", new BigDecimal("25000000"));
    }

    private Order order(Long id, Long userId) {
        return Order.builder().id(id).userId(userId).orderCode("ORD-" + id).status(OrderStatus.CONFIRMED)
                .subtotal(new BigDecimal("25000000")).discountAmount(BigDecimal.ZERO).shippingFee(BigDecimal.ZERO)
                .totalAmount(new BigDecimal("25000000")).recipientName("Nguyen Van A").recipientPhone("0900000000")
                .shippingAddress("Ho Chi Minh City").createdAt(Instant.parse("2026-10-01T10:00:00Z"))
                .updatedAt(Instant.parse("2026-10-01T10:00:00Z")).build();
    }
}
