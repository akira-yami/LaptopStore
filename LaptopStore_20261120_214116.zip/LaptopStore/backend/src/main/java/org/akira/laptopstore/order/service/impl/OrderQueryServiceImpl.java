package org.akira.laptopstore.order.service.impl;

import lombok.RequiredArgsConstructor;
import org.akira.laptopstore.exception.ResourceNotFoundException;
import org.akira.laptopstore.exception.ValidationException;
import org.akira.laptopstore.order.dto.response.OrderItemReviewInfo;
import org.akira.laptopstore.order.entity.Order;
import org.akira.laptopstore.order.entity.OrderItem;
import org.akira.laptopstore.order.entity.enums.OrderStatus;
import org.akira.laptopstore.order.repository.OrderItemRepository;
import org.akira.laptopstore.order.repository.OrderRepository;
import org.akira.laptopstore.order.service.OrderQueryService;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.time.Duration;
import java.time.Instant;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class OrderQueryServiceImpl implements OrderQueryService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;

    @Override
    public BigDecimal getOrderTotalAmount(Long orderId) {
        Order order = findOrderOrThrow(orderId);
        return order.getTotalAmount();
    }

    @Override
    public OrderItemReviewInfo getOrderItemForReview(Long orderItemId) {
        OrderItem orderItem = orderItemRepository.findById(orderItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Order item not found: " + orderItemId));

        return toReviewInfo(orderItem);
    }

    // Lấy thông tin cả một trang review trong một lần gọi
    @Override
    public List<OrderItemReviewInfo> getOrderItemsForReview(Collection<Long> orderItemIds) {
        if (orderItemIds == null || orderItemIds.isEmpty()) {
            return List.of();
        }
        return orderItemRepository.findAllWithOrderByIdIn(orderItemIds)
                .stream()
                .map(this::toReviewInfo)
                .toList();
    }

    // Review theo sản phẩm, điểm trung bình
    @Override
    public List<Long> getOrderItemIdsByProduct(Long productId) {
        if (productId == null || productId <= 0) {
            throw new ValidationException("productId must be greater than 0");
        }
        return orderItemRepository.findIdsByProductId(productId);
    }

    // Review của tôi
    @Override
    public List<Long> getOrderItemIdsByUser(Long userId) {
        if (userId == null || userId <= 0) {
            throw new ValidationException("userId must be greater than 0");
        }
        return orderItemRepository.findIdsByUserId(userId);
    }

    private OrderItemReviewInfo toReviewInfo(OrderItem orderItem) {
        Order order = orderItem.getOrder();

        return OrderItemReviewInfo.builder()
                .orderItemId(orderItem.getId())
                .orderId(order.getId())
                .userId(order.getUserId())
                .productId(orderItem.getProductId())
                .variantId(orderItem.getVariantId())
                .productName(orderItem.getProductName())
                .variantName(orderItem.getVariantName())
                .orderStatus(order.getStatus())
                .build();
    }

    @Override
    public void validateOrderOwner(Long orderId, Long userId) {
        Order order = findOrderOrThrow(orderId);
        if (!order.getUserId().equals(userId)) {
            throw new AccessDeniedException("You do not own this order");
        }
    }

    // ONLINE PAYMENT
    @Override
    public void validateOrderForOnlinePayment(Long orderId) {

        Order order = findOrderOrThrow(orderId);

        if (order.getStatus() != OrderStatus.PENDING_PAYMENT) {

            throw new ValidationException(
                    "Order is not waiting for online payment");
        }
    }

    // COD
    @Override
    public void validateOrderForCodPayment(Long orderId) {

        Order order = findOrderOrThrow(orderId);

        if (order.getStatus() != OrderStatus.WAITING_CONFIRMATION) {

            throw new ValidationException(
                    "Order is not a COD order waiting for confirmation");
        }
    }

    // Deadline VNPay
    @Override
    public Instant getOnlinePaymentDeadline(Long orderId) {

        Order order = findOrderOrThrow(orderId);

        return order.getCreatedAt()
                .plus(Duration.ofMinutes(15));
    }

    @Override
    public void validateOrderDelivered(Long orderId) {
        Order order = findOrderOrThrow(orderId);
        if (order.getStatus() != OrderStatus.DELIVERED) {
            throw new ValidationException("COD can only be collected after delivery");
        }
    }

    private Order findOrderOrThrow(Long orderId) {
        if (orderId == null || orderId <= 0) {
            throw new ValidationException("orderId must be greater than 0");
        }
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }
}