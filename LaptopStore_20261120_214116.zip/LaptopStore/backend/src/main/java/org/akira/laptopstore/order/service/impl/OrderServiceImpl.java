package org.akira.laptopstore.order.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.akira.laptopstore.cart.dto.response.CartItemResponse;
import org.akira.laptopstore.cart.dto.response.CartResponse;
import org.akira.laptopstore.cart.dto.response.CartSnapshot;
import org.akira.laptopstore.cart.service.CartService;
import org.akira.laptopstore.catalog.dto.response.CheckoutVariantSnapshot;
import org.akira.laptopstore.catalog.service.CatalogCheckoutService;
import org.akira.laptopstore.exception.BusinessException;
import org.akira.laptopstore.exception.ResourceNotFoundException;
import org.akira.laptopstore.exception.UnauthenticatedException;
import org.akira.laptopstore.exception.ValidationException;
import org.akira.laptopstore.inventory.dto.request.OrderStockDeduction;
import org.akira.laptopstore.inventory.service.InventoryService;
import org.akira.laptopstore.order.dto.request.CheckoutPreviewRequest;
import org.akira.laptopstore.order.dto.request.CreateOrderRequest;
import org.akira.laptopstore.order.dto.request.UpdateOrderStatusRequest;
import org.akira.laptopstore.order.dto.response.CheckoutPreviewResponse;
import org.akira.laptopstore.order.dto.response.OrderDashboardSummaryResponse;
import org.akira.laptopstore.order.dto.response.OrderItemResponse;
import org.akira.laptopstore.order.dto.response.OrderResponse;
import org.akira.laptopstore.order.dto.response.OrderSummaryResponse;
import org.akira.laptopstore.order.entity.Order;
import org.akira.laptopstore.order.entity.OrderItem;
import org.akira.laptopstore.order.entity.OrderStatusHistory;
import org.akira.laptopstore.order.entity.enums.CheckoutPaymentMethod;
import org.akira.laptopstore.order.entity.enums.OrderStatus;
import org.akira.laptopstore.order.event.OrderCancelledEvent;
import org.akira.laptopstore.order.event.OrderCreatedEvent;
import org.akira.laptopstore.order.mapper.OrderMapper;
import org.akira.laptopstore.order.repository.OrderItemRepository;
import org.akira.laptopstore.order.repository.OrderRepository;
import org.akira.laptopstore.order.repository.OrderStatusHistoryRepository;
import org.akira.laptopstore.order.service.OrderService;
import org.akira.laptopstore.order.service.impl.OrderCheckoutSupport.CheckoutPricing;
import org.akira.laptopstore.order.service.impl.OrderCheckoutSupport.ResolvedShippingAddress;
import org.akira.laptopstore.order.statemachine.OrderStateMachine;
import org.akira.laptopstore.order.util.OrderCodeGenerator;
import org.akira.laptopstore.promotion.dto.response.CouponEvaluation;
import org.akira.laptopstore.promotion.service.CouponService;
import org.akira.laptopstore.promotion.service.LoyaltyService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private static final int EXPIRATION_BATCH_SIZE = 50;
    private static final Set<OrderStatus> COD_CANCELLATION_STATUSES = Set.of(
            OrderStatus.WAITING_CONFIRMATION, OrderStatus.CONFIRMED, OrderStatus.PACKING);

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final OrderStatusHistoryRepository orderStatusHistoryRepository;
    private final OrderMapper orderMapper;
    private final CartService cartService;
    private final CatalogCheckoutService catalogCheckoutService;
    private final InventoryService inventoryService;
    private final CouponService couponService;
    private final LoyaltyService loyaltyService;
    private final OrderCheckoutSupport checkoutSupport;
    private final OrderExpirationTxHelper orderExpirationTxHelper;
    private final ApplicationEventPublisher eventPublisher;

    @Override
    @Transactional(readOnly = true)
    public CheckoutPreviewResponse previewCheckout(Long userId, CheckoutPreviewRequest request) {
        requireUserId(userId);
        CheckoutPreviewRequest safeRequest = request != null ? request : new CheckoutPreviewRequest();

        CheckoutPaymentMethod paymentMethod = CheckoutPaymentMethod.fromValue(safeRequest.getPaymentMethod());
        ResolvedShippingAddress shipping = checkoutSupport.resolveShippingAddress(
                userId,
                safeRequest.getAddressId(),
                safeRequest.getRecipientName(),
                safeRequest.getRecipientPhone(),
                safeRequest.getShippingAddress(),
                false
        );

        CartResponse cart = cartService.getCart(userId);
        if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new ValidationException("Giỏ hàng đang trống");
        }

        List<Long> selectedCartItemIds = normalizeSelectedCartItemIds(safeRequest.getCartItemIds());
        List<CartItemResponse> previewSourceItems = filterSelectedCartItems(cart.getItems(), selectedCartItemIds);

        List<CartSnapshot.Item> cartItems = previewSourceItems.stream()
                .map(item -> new CartSnapshot.Item(item.getCartItemId(), item.getVariantId(), item.getQuantity()))
                .toList();

        Map<Long, CheckoutVariantSnapshot> variants = catalogCheckoutService
                .getSellableVariants(cartItems.stream().map(CartSnapshot.Item::getVariantId).toList())
                .stream()
                .collect(Collectors.toMap(CheckoutVariantSnapshot::getVariantId, variant -> variant));

        checkoutSupport.validateStockBeforeOrder(cartItems, variants);

        String requestedCouponCode = checkoutSupport.normalizeUpper(safeRequest.getCouponCode());
        CheckoutPricing pricing = checkoutSupport.evaluatePricing(cartItems, variants, userId, requestedCouponCode);

        List<OrderItemResponse> previewItems = new ArrayList<>(cartItems.size());
        int totalItems = 0;
        for (CartItemResponse item : previewSourceItems) {
            CheckoutVariantSnapshot variant = checkoutSupport.requireVariant(variants, item.getVariantId());
            BigDecimal lineTotal = variant.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            totalItems += item.getQuantity();
            previewItems.add(new OrderItemResponse(
                    null,
                    variant.getProductId(),
                    variant.getVariantId(),
                    variant.getProductName(),
                    variant.getVariantName(),
                    variant.getSku(),
                    variant.getUnitPrice(),
                    item.getQuantity(),
                    lineTotal
            ));
        }

        return CheckoutPreviewResponse.builder()
                .addressId(shipping.addressId())
                .recipientName(shipping.recipientName())
                .recipientPhone(shipping.recipientPhone())
                .shippingAddress(shipping.shippingAddress())
                .paymentMethod(paymentMethod.name())
                .couponCode(pricing.couponCodeSnapshot())
                .subtotal(pricing.subtotal())
                .discountAmount(pricing.discountAmount())
                .shippingFee(pricing.shippingFee())
                .totalAmount(pricing.totalAmount())
                .totalItems(totalItems)
                .items(List.copyOf(previewItems))
                .build();
    }

    @Override
    @Transactional
    public OrderResponse createOrder(Long userId, CreateOrderRequest request) {
        requireUserId(userId);
        if (request == null) {
            throw new ValidationException("Yêu cầu đặt hàng không được để trống");
        }

        // 1. Validate phương thức thanh toán và địa chỉ giao hàng trước khi tạo order.
        CheckoutPaymentMethod paymentMethod = CheckoutPaymentMethod.fromValue(request.getPaymentMethod());
        OrderStatus initialStatus = resolveInitialStatus(paymentMethod);
        ResolvedShippingAddress resolvedShipping = checkoutSupport.resolveShippingAddress(
                userId,
                request.getAddressId(),
                request.getRecipientName(),
                request.getRecipientPhone(),
                request.getShippingAddress(),
                true
        );
        String requestedCouponCode = checkoutSupport.normalizeUpper(request.getCouponCode());
        List<Long> selectedCartItemIds = normalizeSelectedCartItemIds(request.getCartItemIds());

        // 2. Kiểm tra Idempotency-Key chống tạo đơn trùng.
        String idempotencyKey = checkoutSupport.normalize(request.getIdempotencyKey());
        if (idempotencyKey != null) {
            Order previous = orderRepository.findByIdempotencyKeyAndUserId(idempotencyKey, userId).orElse(null);
            if (previous != null) {
                List<OrderStatusHistory> previousHistories =
                        orderStatusHistoryRepository.findByOrderIdOrderByChangedAtDesc(previous.getId());
                if (!sameCheckoutPayload(previous, previousHistories, resolvedShipping, requestedCouponCode, initialStatus)) {
                    log.warn("Xung đột Idempotency-Key={} cho userId={}: thông tin nhận hàng/coupon/thanh toán không khớp đơn cũ orderId={}",
                            idempotencyKey, userId, previous.getId());
                    throw new BusinessException(
                            HttpStatus.CONFLICT,
                            "IDEMPOTENCY_CONFLICT",
                            "Idempotency-Key đã được sử dụng với dữ liệu đặt hàng khác"
                    );
                }

                List<OrderItem> previousItems = orderItemRepository.findByOrderId(previous.getId());
                CartResponse currentCart = cartService.getCart(userId);
                if (!sameCartAndAmountPayload(previous, previousItems, currentCart, selectedCartItemIds)) {
                    log.warn("Xung đột Idempotency-Key={} cho userId={}: danh sách sản phẩm, số lượng hoặc giá trị giỏ hàng không khớp đơn cũ orderId={}",
                            idempotencyKey, userId, previous.getId());
                    throw new BusinessException(
                            HttpStatus.CONFLICT,
                            "IDEMPOTENCY_CONFLICT",
                            "Idempotency-Key đã được sử dụng với giỏ hàng hoặc giá trị đơn hàng khác"
                    );
                }

                log.info("Phát hiện yêu cầu đặt hàng lặp với Idempotency-Key={} cho userId={}, trả về đơn cũ orderId={}",
                        idempotencyKey, userId, previous.getId());
                return orderMapper.toResponse(
                        previous,
                        previousItems,
                        previousHistories
                );
            }
        }

        // 3. Khóa cart để dữ liệu checkout không bị thay đổi đồng thời (hỗ trợ mua một phần hoặc toàn bộ giỏ).
        CartSnapshot cart = selectedCartItemIds == null
                ? cartService.lockAndGetCheckoutCart(userId)
                : cartService.lockAndGetCheckoutCart(userId, selectedCartItemIds);
        if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new ValidationException("Giỏ hàng đang trống");
        }

        // 4. Khóa variant theo ID tăng dần, xác minh còn bán và lấy snapshot giá/tồn hiện tại.
        Map<Long, CheckoutVariantSnapshot> variants = catalogCheckoutService
                .lockAndGetSellableVariants(cart.getItems().stream()
                        .map(CartSnapshot.Item::getVariantId)
                        .toList())
                .stream()
                .collect(Collectors.toMap(CheckoutVariantSnapshot::getVariantId, variant -> variant));

        // 5. Validate tồn kho của từng biến thể trước khi tạo order.
        checkoutSupport.validateStockBeforeOrder(cart.getItems(), variants);

        // 6. Tính lại subtotal/discount/shipping/total ở server, validate coupon trước khi tạo order.
        CheckoutPricing pricing = checkoutSupport.evaluatePricing(
                cart.getItems(), variants, userId, requestedCouponCode);

        // 7. Lưu order để có ID cho item, coupon usage, lịch sử trạng thái và lịch sử kho.
        // Nếu có 2 request cùng userId + Idempotency-Key chạy song song vượt qua bước 2,
        // ràng buộc uq_orders_user_idempotency_key ở DB sẽ chặn tại đây -> trả về 409 IDEMPOTENCY_CONFLICT thay vì 500.
        Order pendingOrder = Order.builder()
                .userId(userId)
                .orderCode(OrderCodeGenerator.generate())
                .status(initialStatus)
                .paymentMethod(paymentMethod)
                .subtotal(pricing.subtotal())
                .discountAmount(pricing.discountAmount())
                .shippingFee(pricing.shippingFee())
                .totalAmount(pricing.totalAmount())
                .recipientName(resolvedShipping.recipientName())
                .recipientPhone(resolvedShipping.recipientPhone())
                .shippingAddress(resolvedShipping.shippingAddress())
                .couponCodeSnapshot(pricing.couponCodeSnapshot())
                .note(checkoutSupport.normalize(request.getNote()))
                .idempotencyKey(idempotencyKey)
                .build();
        Order order;
        try {
            order = orderRepository.saveAndFlush(pendingOrder);
        } catch (DataIntegrityViolationException ex) {
            if (idempotencyKey != null && isUserIdempotencyConstraintViolation(ex)) {
                log.warn("Phát hiện request đặt hàng đồng thời bị trùng (userId={}, Idempotency-Key={}) bởi constraint DB",
                        userId, idempotencyKey);
                throw new BusinessException(
                        HttpStatus.CONFLICT,
                        "IDEMPOTENCY_CONFLICT",
                        "Yêu cầu đặt hàng với Idempotency-Key này đang được xử lý hoặc đã tồn tại"
                );
            }
            throw ex;
        }

        // 8. Khóa và ghi nhận lượt sử dụng coupon gắn với orderId trong cùng transaction.
        if (requestedCouponCode != null) {
            CouponEvaluation reservedEvaluation = couponService.reserveForOrder(
                    requestedCouponCode,
                    userId,
                    order.getId(),
                    pricing.subtotal()
            );
            if (reservedEvaluation != null) {
                BigDecimal reservedDiscount = checkoutSupport.normalizeDiscount(
                        reservedEvaluation.discountAmount(), pricing.subtotal());
                String reservedCode = reservedEvaluation.couponCode() != null
                        ? reservedEvaluation.couponCode().trim().toUpperCase(Locale.ROOT)
                        : requestedCouponCode;
                BigDecimal reservedTotal = checkoutSupport.calculateTotalAmount(
                        pricing.subtotal(), reservedDiscount, pricing.shippingFee());

                if (order.getDiscountAmount().compareTo(reservedDiscount) != 0
                        || order.getTotalAmount().compareTo(reservedTotal) != 0
                        || !Objects.equals(order.getCouponCodeSnapshot(), reservedCode)) {
                    order.setDiscountAmount(reservedDiscount);
                    order.setTotalAmount(reservedTotal);
                    order.setCouponCodeSnapshot(reservedCode);
                    orderRepository.save(order);
                }
            }
        }

        // 9. Lưu snapshot sản phẩm để dữ liệu đơn không đổi khi catalog được cập nhật.
        List<OrderItem> items = cart.getItems().stream().map(cartItem -> {
            CheckoutVariantSnapshot variant = checkoutSupport.requireVariant(variants, cartItem.getVariantId());
            return OrderItem.builder()
                    .order(order)
                    .productId(variant.getProductId())
                    .variantId(variant.getVariantId())
                    .productName(variant.getProductName())
                    .variantName(variant.getVariantName())
                    .sku(variant.getSku())
                    .unitPrice(variant.getUnitPrice())
                    .quantity(cartItem.getQuantity())
                    .build();
        }).toList();
        orderItemRepository.saveAll(items);

        // 10. Đơn mới bắt đầu ở trạng thái initialStatus.
        OrderStatusHistory history = orderStatusHistoryRepository.save(OrderStatusHistory.builder()
                .order(order)
                .toStatus(initialStatus)
                .changedAt(Instant.now())
                .changedByUserId(userId)
                .build());

        // 11. Trừ tồn và ghi stock movement; lỗi sẽ rollback toàn bộ checkout.
        inventoryService.deductForOrder(
                order.getId(),
                userId,
                cart.getItems().stream()
                        .map(item -> new OrderStockDeduction(item.getVariantId(), item.getQuantity()))
                        .toList()
        );

        // 12. Chỉ xóa cart sau khi đã tạo order và trừ tồn thành công.
        cartService.clearPurchasedItems(
                userId,
                cart.getItems().stream().map(CartSnapshot.Item::getCartItemId).toList()
        );

        // 13. Phát sự kiện tạo đơn trong cùng transaction để module payment tự khởi tạo bản ghi Payment PENDING,
        // tránh trường hợp đơn COD/VNPay bị mồ côi bản ghi payment nếu client rớt mạng sau khi tạo đơn.
        eventPublisher.publishEvent(new OrderCreatedEvent(
                order.getId(),
                userId,
                paymentMethod,
                order.getTotalAmount(),
                order.getCreatedAt()
        ));

        log.info("Tạo đơn hàng thành công: orderId={}, orderCode={}, userId={}, trạng thái={}, tổng tiền={}",
                order.getId(), order.getOrderCode(), userId, initialStatus, order.getTotalAmount());

        return orderMapper.toResponse(order, items, List.of(history));
    }

    @Override
    @Transactional(readOnly = true)
    public OrderResponse getOwnOrder(Long userId, Long orderId) {
        requireUserId(userId);
        requireOrderId(orderId);
        Order order = orderRepository.findById(orderId)
                .filter(candidate -> userId.equals(candidate.getUserId()))
                .orElseThrow(() -> new ResourceNotFoundException("Đơn hàng không được tìm thấy!"));
        return toDetailResponse(order);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrderSummaryResponse> getOwnOrders(Long userId, Pageable pageable) {
        return getOwnOrders(userId, null, pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrderSummaryResponse> getOwnOrders(Long userId, List<OrderStatus> statuses, Pageable pageable) {
        requireUserId(userId);
        if (statuses == null || statuses.isEmpty()) {
            return toSummaryPage(orderRepository.findByUserId(userId, pageable));
        }
        return toSummaryPage(orderRepository.findByUserIdAndStatusIn(userId, statuses, pageable));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrderSummaryResponse> getAllOrders(Pageable pageable) {
        return getAllOrders(null, null, pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrderSummaryResponse> getAllOrders(OrderStatus status, String keyword, Pageable pageable) {
        String normalizedKeyword = checkoutSupport.normalize(keyword);
        if (status == null && normalizedKeyword == null) {
            return toSummaryPage(orderRepository.findAll(pageable));
        }
        String keywordPattern = normalizedKeyword == null
                ? ""
                : "%" + normalizedKeyword.toLowerCase(Locale.ROOT) + "%";
        return toSummaryPage(orderRepository.searchAllOrders(status, keywordPattern, pageable));
    }

    @Override
    @Transactional(readOnly = true)
    public OrderDashboardSummaryResponse getDashboardSummary() {
        long totalOrders = 0;
        long pendingCount = 0;
        long inProgressCount = 0;
        long deliveredCount = 0;
        BigDecimal deliveredRevenue = BigDecimal.ZERO;

        for (Object[] row : orderRepository.summarizeByStatus()) {
            OrderStatus status = (OrderStatus) row[0];
            long count = row[1] == null ? 0L : ((Number) row[1]).longValue();
            BigDecimal amount = row[2] == null ? BigDecimal.ZERO : new BigDecimal(row[2].toString());
            totalOrders += count;
            if (status == OrderStatus.CREATED
                    || status == OrderStatus.PENDING_PAYMENT
                    || status == OrderStatus.WAITING_CONFIRMATION) {
                pendingCount += count;
            } else if (status == OrderStatus.CONFIRMED
                    || status == OrderStatus.PACKING
                    || status == OrderStatus.SHIPPING
                    || status == OrderStatus.DELIVERY_FAILED) {
                inProgressCount += count;
            } else if (status == OrderStatus.DELIVERED) {
                deliveredCount += count;
                deliveredRevenue = deliveredRevenue.add(amount);
            }
        }

        return OrderDashboardSummaryResponse.builder()
                .totalOrders(totalOrders)
                .pendingCount(pendingCount)
                .inProgressCount(inProgressCount)
                .deliveredCount(deliveredCount)
                .deliveredRevenue(deliveredRevenue)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public OrderResponse getStaffOrder(Long orderId) {
        requireOrderId(orderId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đơn hàng"));
        return toDetailResponse(order);
    }

    @Override
    @Transactional
    public OrderResponse updateOrderStatus(Long actorId, Long orderId, UpdateOrderStatusRequest request) {
        requireUserId(actorId);
        requireOrderId(orderId);
        if (request == null || request.getStatus() == null) {
            throw new ValidationException("Trạng thái đơn hàng không được để trống");
        }

        Order order = orderRepository.findByIdForUpdate(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đơn hàng: " + orderId));

        OrderStatus currentStatus = order.getStatus();
        OrderStatus targetStatus = request.getStatus();

        // Lệnh cập nhật lặp lại cùng trạng thái: trả về kết quả hiện tại, không ghi thêm lịch sử hay hoàn kho/coupon lần hai.
        if (currentStatus == targetStatus) {
            return toDetailResponse(order);
        }
        String cancellationReason = order.getCancellationRequestReason();
        if (cancellationReason != null && targetStatus != OrderStatus.CANCELLED) {
            throw new BusinessException(HttpStatus.CONFLICT, "CANCELLATION_REQUEST_PENDING",
                    "Đơn hàng đang chờ duyệt yêu cầu hủy");
        }
        if (currentStatus == OrderStatus.PACKING && targetStatus == OrderStatus.CANCELLED
                && cancellationReason == null) {
            throw new ValidationException("Đơn đang chuẩn bị chỉ được hủy khi khách hàng đã gửi yêu cầu");
        }
        if (currentStatus == OrderStatus.PENDING_PAYMENT && targetStatus == OrderStatus.CONFIRMED) {
            throw new ValidationException("Đơn online phải được xác nhận qua kết quả thanh toán");
        }

        int deliveryAttempts = (int) orderStatusHistoryRepository.findByOrderIdOrderByChangedAtDesc(orderId).stream()
                .filter(h -> h.getToStatus() == OrderStatus.DELIVERY_FAILED)
                .count();

        OrderStateMachine.validateTransition(currentStatus, targetStatus, true, deliveryAttempts);

        order.setStatus(targetStatus);
        order.setCancellationRequestReason(null);
        orderRepository.save(order);

        orderStatusHistoryRepository.save(OrderStatusHistory.builder()
                .order(order)
                .fromStatus(currentStatus)
                .toStatus(targetStatus)
                .changedAt(Instant.now())
                .changedByUserId(actorId)
                .note(cancellationReason != null ? cancellationReason : checkoutSupport.normalize(request.getNote()))
                .build());

        // Tách rõ 2 nghiệp vụ:
        // - CANCELLED: hoàn kho CANCEL_RESTORE + nhả lượt coupon + phát sự kiện hủy Payment PENDING.
        // - RETURNED (trả hàng sau giao): chỉ hoàn kho loại RETURN; KHÔNG nhả coupon đã tiêu dùng và KHÔNG hủy Payment đã PAID.
        if (targetStatus == OrderStatus.CANCELLED) {
            handleOrderCancellationSideEffects(order, actorId);
            eventPublisher.publishEvent(new OrderCancelledEvent(order.getId(), false));
        } else if (targetStatus == OrderStatus.RETURNED) {
            handleOrderReturnSideEffects(order, actorId);
        } else if (targetStatus == OrderStatus.DELIVERED) {
            loyaltyService.awardPointsForDeliveredOrder(
                    order.getUserId(),
                    order.getId(),
                    order.getOrderCode(),
                    order.getTotalAmount()
            );
        }

        log.info("Cập nhật trạng thái đơn hàng thành công: orderId={}, từ [{}] sang [{}], actorId={}",
                orderId, currentStatus, targetStatus, actorId);

        return toDetailResponse(order);
    }

    @Override
    @Transactional
    public OrderResponse cancelOrder(Long userId, Long orderId, String reason) {
        requireUserId(userId);
        requireOrderId(orderId);

        Order order = orderRepository.findByIdForUpdate(orderId)
                .filter(candidate -> userId.equals(candidate.getUserId()))
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đơn hàng"));

        OrderStatus currentStatus = order.getStatus();

        if (currentStatus == OrderStatus.CANCELLED) {
            log.info("Đơn hàng đã ở trạng thái CANCELLED trước đó: orderId={}, userId={}, bỏ qua xử lý lặp",
                    orderId, userId);
            return toDetailResponse(order);
        }
        if (order.getPaymentMethod() == CheckoutPaymentMethod.COD) {
            if (!COD_CANCELLATION_STATUSES.contains(currentStatus)) {
                throw new ValidationException("Đơn COD chỉ được yêu cầu hủy khi chờ xác nhận, đã xác nhận hoặc đang chuẩn bị");
            }
            if (order.getCancellationRequestReason() == null) {
                String requestReason = checkoutSupport.normalize(reason);
                if (requestReason != null && requestReason.length() > 500) {
                    throw new ValidationException("Lý do hủy đơn không được vượt quá 500 ký tự");
                }
                order.setCancellationRequestReason(requestReason != null ? requestReason : "Khách hàng yêu cầu hủy");
                orderRepository.save(order);
            }
            return toDetailResponse(order);
        }
        OrderStateMachine.validateTransition(currentStatus, OrderStatus.CANCELLED, false, 0);

        order.setStatus(OrderStatus.CANCELLED);
        orderRepository.save(order);

        String normalizedReason = checkoutSupport.normalize(reason);
        orderStatusHistoryRepository.save(OrderStatusHistory.builder()
                .order(order)
                .fromStatus(currentStatus)
                .toStatus(OrderStatus.CANCELLED)
                .changedAt(Instant.now())
                .changedByUserId(userId)
                .note(normalizedReason)
                .build());

        handleOrderCancellationSideEffects(order, userId);
        eventPublisher.publishEvent(new OrderCancelledEvent(order.getId(), false));

        log.info("Khách hàng đã hủy đơn hàng: orderId={}, từ [{}] sang [CANCELLED], userId={}, lý do={}",
                orderId, currentStatus, userId, normalizedReason);

        return toDetailResponse(order);
    }

    @Override
    public int expirePendingOrders(Duration timeout) {
        if (timeout == null || timeout.isNegative() || timeout.isZero()) {
            timeout = Duration.ofMinutes(15);
        }
        Instant cutoffTime = Instant.now().minus(timeout);
        // Quét theo lô nhỏ (tối đa 50 đơn/lượt) và xử lý từng đơn trong transaction REQUIRES_NEW độc lập,
        // tránh lỗi ở 1 đơn làm rollback toàn bộ các đơn quá hạn khác trong cùng đợt quét.
        List<Long> candidateIds = orderRepository.findIdsByStatusAndCreatedAtBefore(
                OrderStatus.PENDING_PAYMENT,
                cutoffTime,
                PageRequest.of(0, EXPIRATION_BATCH_SIZE)
        );
        int count = 0;

        for (Long orderId : candidateIds) {
            try {
                if (orderExpirationTxHelper.expireSinglePendingOrder(orderId, cutoffTime)) {
                    count++;
                }
            } catch (RuntimeException ex) {
                log.error("Không thể tự động hủy đơn quá hạn orderId={}: {}", orderId, ex.getMessage(), ex);
            }
        }

        if (count > 0) {
            log.info("Đã tự động hủy {} đơn hàng chờ thanh toán online quá hạn (tạo trước {})", count, cutoffTime);
        }

        return count;
    }

    @Override
    public int expirePendingOrders() {
        return expirePendingOrders(Duration.ofMinutes(15));
    }

    private Page<OrderSummaryResponse> toSummaryPage(Page<Order> orderPage) {
        if (orderPage.isEmpty()) {
            return orderPage.map(order -> orderMapper.toSummaryResponse(order, 0));
        }

        List<Long> orderIds = orderPage.getContent().stream()
                .map(Order::getId)
                .toList();
        Map<Long, Integer> totalItemsByOrderId = new HashMap<>(orderIds.size());
        for (Object[] row : orderItemRepository.sumQuantitiesByOrderIds(orderIds)) {
            Long id = ((Number) row[0]).longValue();
            int total = row[1] == null ? 0 : ((Number) row[1]).intValue();
            totalItemsByOrderId.put(id, total);
        }

        return orderPage.map(order ->
                orderMapper.toSummaryResponse(order, totalItemsByOrderId.getOrDefault(order.getId(), 0)));
    }

    private OrderResponse toDetailResponse(Order order) {
        return orderMapper.toResponse(
                order,
                orderItemRepository.findByOrderId(order.getId()),
                orderStatusHistoryRepository.findByOrderIdOrderByChangedAtDesc(order.getId())
        );
    }

    private void handleOrderCancellationSideEffects(Order order, Long actorId) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getId());
        List<OrderStockDeduction> lines = items.stream()
                .map(item -> new OrderStockDeduction(item.getVariantId(), item.getQuantity()))
                .toList();

        if (!lines.isEmpty()) {
            inventoryService.restoreForOrder(order.getId(), actorId, lines);
        }

        if (order.getCouponCodeSnapshot() != null) {
            couponService.releaseForOrder(order.getId());
        }
    }

    private void handleOrderReturnSideEffects(Order order, Long actorId) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getId());
        List<OrderStockDeduction> lines = items.stream()
                .map(item -> new OrderStockDeduction(item.getVariantId(), item.getQuantity()))
                .toList();

        if (!lines.isEmpty()) {
            inventoryService.restoreForReturnedOrder(order.getId(), actorId, lines);
        }
    }

    private OrderStatus resolveInitialStatus(CheckoutPaymentMethod paymentMethod) {
        return paymentMethod == CheckoutPaymentMethod.VNPAY
                ? OrderStatus.PENDING_PAYMENT
                : OrderStatus.WAITING_CONFIRMATION;
    }

    // Hàm này được dùng để kiểm tra tính Idempotency, xem 1 yêu cầu đặt hàng có bị gửi nhiều lần không
    private boolean sameCheckoutPayload(
            Order order,
            List<OrderStatusHistory> histories,
            ResolvedShippingAddress resolvedShipping,
            String requestedCouponCode,
            OrderStatus expectedInitialStatus
    ) {
        OrderStatus originalInitialStatus = histories.stream()
                .filter(h -> h.getFromStatus() == null)
                .map(OrderStatusHistory::getToStatus)
                .findFirst()
                .orElse(order.getStatus());

        return Objects.equals(order.getRecipientName(), resolvedShipping.recipientName())
                && Objects.equals(order.getRecipientPhone(), resolvedShipping.recipientPhone())
                && Objects.equals(order.getShippingAddress(), resolvedShipping.shippingAddress())
                && Objects.equals(checkoutSupport.normalizeUpper(order.getCouponCodeSnapshot()), requestedCouponCode)
                && originalInitialStatus == expectedInitialStatus;
    }

    /**
     * Đối chiếu giỏ hàng hiện tại với các dòng hàng và tổng tiền của đơn cũ khi phát hiện trùng Idempotency-Key.
     * - Nếu giỏ hiện tại đang rỗng: lần checkout trước đã xóa giỏ sau khi commit thành công (bước 12),
     *   nên đây là retry hợp lệ do lỗi mạng -> cho phép trả lại đơn cũ.
     * - Nếu giỏ hiện tại còn sản phẩm: bắt buộc phải khớp toàn bộ biến thể, số lượng, đơn giá từng biến thể
     *   và tổng tạm tính (subtotal) của đơn cũ; nếu lệch sẽ báo 409 IDEMPOTENCY_CONFLICT.
     */
    private boolean sameCartAndAmountPayload(
            Order previous,
            List<OrderItem> previousItems,
            CartResponse currentCart,
            List<Long> selectedCartItemIds
    ) {
        if (currentCart == null || currentCart.getItems() == null || currentCart.getItems().isEmpty()) {
            return true;
        }
        List<CartItemResponse> relevantItems;
        if (selectedCartItemIds == null) {
            relevantItems = currentCart.getItems();
        } else {
            java.util.Set<Long> selectedSet = new java.util.HashSet<>(selectedCartItemIds);
            relevantItems = currentCart.getItems().stream()
                    .filter(item -> selectedSet.contains(item.getCartItemId()))
                    .toList();
            if (relevantItems.isEmpty()) {
                // Các dòng đã mua trong lần checkout đầu đã bị clearPurchasedItems xóa khỏi giỏ -> retry hợp lệ.
                return true;
            }
        }
        if (previousItems == null || previousItems.isEmpty()) {
            return false;
        }

        // 1. Gom số lượng và đơn giá theo từng variantId từ đơn hàng đã tạo trước đó.
        Map<Long, Integer> previousQtyByVariant = new HashMap<>();
        Map<Long, BigDecimal> previousPriceByVariant = new HashMap<>();
        for (OrderItem item : previousItems) {
            previousQtyByVariant.merge(item.getVariantId(), item.getQuantity(), Integer::sum);
            previousPriceByVariant.putIfAbsent(item.getVariantId(), item.getUnitPrice());
        }

        // 2. Gom số lượng theo từng variantId và tính lại tổng tạm tính từ giỏ hàng hiện tại.
        Map<Long, Integer> currentQtyByVariant = new HashMap<>();
        BigDecimal currentSubtotal = BigDecimal.ZERO;
        for (CartItemResponse item : relevantItems) {
            if (item.getVariantId() == null || item.getQuantity() == null || item.getUnitPrice() == null) {
                return false;
            }
            BigDecimal previousUnitPrice = previousPriceByVariant.get(item.getVariantId());
            if (previousUnitPrice == null || previousUnitPrice.compareTo(item.getUnitPrice()) != 0) {
                return false;
            }
            currentQtyByVariant.merge(item.getVariantId(), item.getQuantity(), Integer::sum);
            currentSubtotal = currentSubtotal.add(
                    item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity()))
            );
        }

        // 3. Kiểm tra khớp hoàn toàn tập biến thể + số lượng và giá trị tạm tính của đơn hàng.
        if (!Objects.equals(previousQtyByVariant, currentQtyByVariant)) {
            return false;
        }
        return previous.getSubtotal() != null && previous.getSubtotal().compareTo(currentSubtotal) == 0;
    }

    private List<Long> normalizeSelectedCartItemIds(List<Long> rawIds) {
        if (rawIds == null || rawIds.isEmpty()) {
            return null;
        }
        java.util.LinkedHashSet<Long> unique = new java.util.LinkedHashSet<>();
        for (Long id : rawIds) {
            if (id == null || id <= 0) {
                throw new ValidationException("Danh sách cartItemIds phải chứa các ID hợp lệ (> 0)");
            }
            unique.add(id);
        }
        return List.copyOf(unique);
    }

    private List<CartItemResponse> filterSelectedCartItems(
            List<CartItemResponse> allItems,
            List<Long> selectedCartItemIds
    ) {
        if (selectedCartItemIds == null) {
            return allItems;
        }
        Map<Long, CartItemResponse> byId = allItems.stream()
                .collect(Collectors.toMap(CartItemResponse::getCartItemId, item -> item, (a, b) -> a));
        List<CartItemResponse> selected = new ArrayList<>(selectedCartItemIds.size());
        for (Long id : selectedCartItemIds) {
            CartItemResponse item = byId.get(id);
            if (item == null) {
                throw new ResourceNotFoundException("Không tìm thấy sản phẩm trong giỏ hàng: " + id);
            }
            selected.add(item);
        }
        return selected;
    }

    private boolean isUserIdempotencyConstraintViolation(DataIntegrityViolationException ex) {
        Throwable cursor = ex;
        while (cursor != null) {
            String message = cursor.getMessage();
            if (message != null) {
                String lower = message.toLowerCase(Locale.ROOT);
                if (lower.contains("uq_orders_user_idempotency_key")
                        || lower.contains("uq_orders_idempotency_key")
                        || lower.contains("orders_idempotency_key_key")) {
                    return true; // Lỗi này do lỗi của khóa trùng
                }
            }
            cursor = cursor.getCause();
        }
        return false; // Lỗi do nguyên nhân khác. VD: trùng mã đơn hàng, vi phạm khóa ngoại, sai kiểu dữ liệu
    }

    private void requireUserId(Long userId) {
        if (userId == null || userId <= 0) {
            throw new UnauthenticatedException("Thông tin người dùng đăng nhập không hợp lệ");
        }
    }

    private void requireOrderId(Long orderId) {
        if (orderId == null || orderId <= 0) {
            throw new ValidationException("Mã đơn hàng (orderId) phải lớn hơn 0");
        }
    }
}
