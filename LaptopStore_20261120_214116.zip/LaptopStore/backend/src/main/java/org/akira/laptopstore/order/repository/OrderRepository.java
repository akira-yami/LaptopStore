package org.akira.laptopstore.order.repository;

import org.akira.laptopstore.order.entity.Order;
import org.akira.laptopstore.order.entity.enums.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select o from Order o where o.id = :id")
    Optional<Order> findByIdForUpdate(@Param("id") Long id);

    Optional<Order> findByOrderCode(String orderCode);

    Page<Order> findByUserId(Long userId, Pageable pageable);

    Page<Order> findByStatus(OrderStatus status, Pageable pageable);

    Page<Order> findByUserIdAndStatus(Long userId, OrderStatus status, Pageable pageable);

    Page<Order> findByUserIdAndStatusIn(Long userId, Collection<OrderStatus> statuses, Pageable pageable);

    @Query("""
            select o from Order o
            where (:status is null or o.status = :status)
              and (:keywordPattern = ''
                   or lower(o.orderCode) like :keywordPattern
                   or lower(o.recipientName) like :keywordPattern)
            """)
    Page<Order> searchAllOrders(@Param("status") OrderStatus status,
                                @Param("keywordPattern") String keywordPattern,
                                Pageable pageable);

    Optional<Order> findByIdempotencyKeyAndUserId(String idempotencyKey, Long userId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select o from Order o where o.status = :status and o.createdAt < :cutoffTime order by o.id")
    List<Order> findByStatusAndCreatedAtBefore(@Param("status") OrderStatus status,
                                               @Param("cutoffTime") Instant cutoffTime);

    @Query("select o.id from Order o where o.status = :status and o.createdAt < :cutoffTime order by o.id asc")
    List<Long> findIdsByStatusAndCreatedAtBefore(@Param("status") OrderStatus status,
                                                 @Param("cutoffTime") Instant cutoffTime,
                                                 Pageable pageable);

    @Query(value = "SELECT * FROM orders WHERE id = :id FOR UPDATE SKIP LOCKED", nativeQuery = true)
    Optional<Order> findByIdForUpdateSkipLocked(@Param("id") Long id);

    @Query("select o.status, count(o), coalesce(sum(o.totalAmount), 0) from Order o group by o.status")
    List<Object[]> summarizeByStatus();
}
