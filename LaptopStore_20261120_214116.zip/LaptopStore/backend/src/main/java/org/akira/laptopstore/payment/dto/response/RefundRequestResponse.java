package org.akira.laptopstore.payment.dto.response;

import org.akira.laptopstore.payment.enums.RefundRequestStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record RefundRequestResponse(
        Long id,
        Long orderId,
        BigDecimal amount,
        String reason,
        RefundRequestStatus status,
        Instant createdAt,
        Instant reviewedAt,
        Long reviewedByUserId,
        String reviewNote,
        List<Long> evidenceIds
) {}
