import { apiErrorMessage, formatDateTime, formatMoney, Modal, PageHeading, Pager, Spinner, useToast } from '@/components/ui';
import { useEffect, useState } from 'react';
import { refundApi } from '../../api/refundApi';
import { RefundRequestDetails, RefundStatusBadge } from '../../components/RefundRequestDetails';
import type { RefundRequest, RefundRequestStatus } from '../../types';

const FILTERS: { status: RefundRequestStatus; label: string }[] = [
  { status: 'PENDING', label: 'Chờ duyệt' },
  { status: 'APPROVED', label: 'Đã duyệt' },
  { status: 'REJECTED', label: 'Đã từ chối' },
];

export const AdminRefundRequestsPage = () => {
  const toast = useToast();
  const [status, setStatus] = useState<RefundRequestStatus>('PENDING');
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [reload, setReload] = useState(0);
  const [requests, setRequests] = useState<RefundRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [selected, setSelected] = useState<RefundRequest | null>(null);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(false);
    refundApi.list(page, status).then((result) => {
      if (!active) return;
      setRequests(result.content);
      setTotalPages(result.totalPages);
      if (page > 0 && result.content.length === 0) setPage(Math.max(0, result.totalPages - 1));
    }).catch(() => {
      if (active) setError(true);
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [page, status, reload]);

  const review = async (approved: boolean) => {
    if (!selected || saving || (!approved && !note.trim())) return;
    try {
      setSaving(true);
      await refundApi.review(selected.id, approved, note.trim() || undefined);
      toast(approved ? 'Đã duyệt yêu cầu hoàn tiền.' : 'Đã từ chối yêu cầu hoàn tiền.');
      setSelected(null);
      setReload((current) => current + 1);
    } catch (err) {
      toast(apiErrorMessage(err, 'Không thể xử lý yêu cầu hoàn tiền.'), { tone: 'error' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <PageHeading
        title="Yêu cầu hoàn tiền"
        actions={<button type="button" className="btn sm" onClick={() => setReload((current) => current + 1)}>Làm mới</button>}
      />
      <div className="chips" aria-label="Lọc theo trạng thái">
        {FILTERS.map((filter) => (
          <button key={filter.status} type="button" className={`chip ${status === filter.status ? 'active' : ''}`}
            aria-pressed={status === filter.status} onClick={() => {
              setStatus(filter.status);
              setPage(0);
            }}>
            {filter.label}
          </button>
        ))}
      </div>
      {loading ? <Spinner /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Yêu cầu</th><th>Đơn hàng</th><th>Số tiền</th><th>Thời gian gửi</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
            <tbody>
              {error || requests.length === 0 ? (
                <tr><td className="table-empty" colSpan={6}>
                  {error ? 'Không thể tải yêu cầu hoàn tiền.' : 'Không có yêu cầu hoàn tiền ở trạng thái này.'}
                </td></tr>
              ) : requests.map((request) => (
                <tr key={request.id}>
                  <td className="primary-cell">#{request.id}</td>
                  <td>#{request.orderId}</td>
                  <td>{formatMoney(request.amount)}</td>
                  <td>{formatDateTime(request.createdAt)}</td>
                  <td><RefundStatusBadge status={request.status} /></td>
                  <td><button type="button" className="btn sm" onClick={() => {
                    setSelected(request);
                    setNote('');
                  }}>{request.status === 'PENDING' ? 'Xem và xử lý' : 'Xem chi tiết'}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {!loading && !error && <Pager page={page} totalPages={totalPages} onChange={setPage} />}
      <Modal
        open={!!selected}
        title={selected ? `Yêu cầu hoàn tiền #${selected.id} · Đơn #${selected.orderId}` : ''}
        onClose={() => { if (!saving) setSelected(null); }}
        wide
        actions={selected?.status === 'PENDING' && (
          <>
            <button type="button" className="btn danger" disabled={saving || !note.trim()}
              onClick={() => void review(false)}>Từ chối</button>
            <button type="button" className="btn primary" disabled={saving}
              onClick={() => void review(true)}>{saving ? 'Đang lưu…' : 'Duyệt yêu cầu'}</button>
          </>
        )}
      >
        {selected && (
          <div className="stack">
            <RefundRequestDetails request={selected} scope="admin" />
            {selected.status === 'PENDING' && (
              <label className="field">
                <span id="refund-review-note-label">Ghi chú xử lý</span>
                <textarea rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)}
                  aria-labelledby="refund-review-note-label" aria-describedby="refund-review-note-help" />
                <small id="refund-review-note-help" className="muted">Nhập lý do nếu từ chối yêu cầu.</small>
              </label>
            )}
          </div>
        )}
      </Modal>
    </>
  );
};
